<template>
    <div>
        <table class="table">
            <thead>
                <tr class="head">
                    <th>день</th>
                    <th v-for="day in days">
                        <span>{{ day.day_of_week.toUpperCase() }}</span>
                        <span :class="isCurrentDay(day) ? 'today' : ''">
                            <span :class="dayIsHoliday(day) ? 'daygrid-day-number holiday' : ''"
                                  @click="dayClickHandler(day)">
                                <router-link
                                    to="/"
                                :style="{ }">
                                    <span :style="isCurrentDay(day) || dayIsHoliday(day) ? '' : {color: '#808080'}">
                                        {{ day.day_of_month }}
                                    </span>
                                </router-link>
                            </span>
                        </span>
                        <!--     holiday               -->
                        <template v-if="dayIsHoliday(day)">
                            <div class="daygrid-day-ukr" v-for="holiday in getHolidaysByDay(day)">
                                {{ holiday.summary}}
                            </div>
                        </template>
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="time in times">
                <td>{{ time.format('HH:mm') }}</td>
                <td v-for="day in days">

                    <!--                    {{ getEventsForThisDateTime(day, time) }}-->
                    <template v-for="event in allEventsForWeek">
                        <template v-if="isEventDateTime(event, day, time)">
                            <template v-if="event.type === 'event'">
                                <div class="daygrid-day-event" :id="`event-`+event.id+'-'+day.index">
                                    {{ event.name }}
                                    <edit-modal
                                        :id="`event-`+event.id+'-'+day.index"
                                        :event="event"
                                    >
                                    </edit-modal>
                                </div>
                            </template>
                            <template v-if="event.type === 'reminder'">
                                <div class="daygrid-day-reminder" :id="`reminder-`+event.id+'-'+day.index">
                                    {{ event.name }}
                                    <edit-modal
                                        :id="`reminder-`+event.id+'-'+day.index"
                                        :event="event"
                                    >
                                    </edit-modal>
                                </div>
                            </template>
                            <template v-if="event.type === 'task'">
                                <div class="daygrid-day-task" :id="`task-`+event.id+'-'+day.index">
                                    {{ event.name }}
                                    <edit-modal
                                        :id="`task-`+event.id+'-'+day.index"
                                        :event="event"
                                    >
                                    </edit-modal>
                                </div>
                            </template>
                            <template v-if="event.type === 'birthday'">
                                <div class="daygrid-day-birthday" :id="`birthday-`+event.id+'-'+day.index">
                                    {{ event.name }}
                                    <edit-modal
                                        :id="`birthday-`+event.id+'-'+day.index"
                                        :event="event"
                                    >
                                    </edit-modal>
                                </div>
                            </template>
                        </template>
                    </template>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</template>
<script>

import DayCalendarNavigation from "../DayCalendar/DayCalendarComponents/DayCalendarNavigation";
import {mapGetters, mapMutations} from 'vuex'
import EditModal from "../Events/Edit/EditModal";

export default {
    name: "Week",
    components: {
        DayCalendarNavigation,
        EditModal,
    },

    data() {

        return {
            dFirstMonth: 1,
            months: ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"],
            date: new Date(),
            days: [],
            daysOfCurrentWeek: [],
        }
    },
    mounted() {
        this.setIsWeek(true)
        this.setTitleNavigationCalendarWeek(this.months[this.month] + ' ' + this.year)
    },
    beforeDestroy() {
        this.setIsWeek(false)
    },
    computed: {
        isWeek() {
            return this.isWeek
        },
        holidays() {
            return this.holidays
        },
        allEventsForWeek() {
            return this.allEventsForDay
        },
        titleNavigationCalendarWeek(state) {
            return state.titleNavigationCalendarWeek
        },
        month() {
            return this.monthCalendarMonth
        },
        year() {
            return this.yearCalendarWeek
        },

        ...mapGetters([
            'isWeek',
            'allEventsForDay',
            'holidays',
            'titleNavigationCalendarWeek',
            'weekCalendarWeek',
            'monthCalendarMonth',
            'yearCalendarWeek',
        ]),
        times() {
            let times = [];

            for (let i = 0; i <= 23; i++) {
                times.push(this.$moment(i, 'hh'));
            }

            return times;
        },
    },
    created() {
        const startDateOfCurrentWeek = this.$moment().year(this.yearCalendarWeek).weekday(0).week(this.weekCalendarWeek);
        const endDateOfCurrentWeek = this.$moment().year(this.yearCalendarWeek).weekday(6).week(this.weekCalendarWeek);
        this.daysOfCurrentWeek = this.getDaysBetweenTwoDates(startDateOfCurrentWeek, endDateOfCurrentWeek);
        this.days = this.daysOfCurrentWeek;
    },

    watch: {
        weekCalendarWeek(week) {
            const startDateOfCurrentWeek = this.$moment().year(this.yearCalendarWeek).weekday(0).week(week);
            const endDateOfCurrentWeek = this.$moment().year(this.yearCalendarWeek).weekday(6).week(week);
            this.daysOfCurrentWeek = this.getDaysBetweenTwoDates(startDateOfCurrentWeek, endDateOfCurrentWeek);
            this.days = this.daysOfCurrentWeek;
        },
    },

    methods: {
        ...mapMutations([
            'setIsWeek',
            'prevWeek',
            'nextWeek',
        ]),

        getDaysBetweenTwoDates(startDate, endDate) {
            let now = startDate.clone(), days = [];

            while (now.isSameOrBefore(endDate)) {
                let day = {};
                day.day_of_week = now.format('dddd');
                day.day_of_month = now.format('D');
                day.full_date = now.format();
                days.push(day);
                now.add(1, 'days');
            }
            return days;
        },
        isCurrentDay(day) {
            const currentDate = this.$moment().format('M-D-Y');
            const thisDate = this.$moment(day.full_date).format('M-D-Y');
            if (currentDate === thisDate) {
                return true;
            }
            return false;
        },

        prevWeek() {
            const startDate = this.$moment(this.days[0].full_date).subtract('7', 'days');
            const endDate = this.$moment(this.days[this.days.length - 1].full_date).subtract('7', 'days');
            this.days = this.getDaysBetweenTwoDates(startDate, endDate);
        },
        nextWeek() {
            const startDate = this.$moment(this.days[0].full_date).add('7', 'days');
            const endDate = this.$moment(this.days[this.days.length - 1].full_date).add('7', 'days');
            this.days = this.getDaysBetweenTwoDates(startDate, endDate);

        },
        switchMonth() {
            const newMonth = this.$moment().format('MMMM');
        },
        byField(field) {
            return (a, b) => a[field] > b[field] ? 1 : -1
        },
        isEventDateTime(event, date, time) {
            const thisDate = this.$moment(date.full_date).format('YYYY-MM-D');
            const thisTime = this.$moment(time).format('HH:mm:ss');

            if (event.dateStart === thisDate && event.timeStart === thisTime) {
                return true;
            }

            return false;
        },
        dayIsHoliday(day) {
            const thisDate = this.$moment(day.full_date).format('YYYY-MM-DD');
            if (this.holidays[thisDate]) {
                return true;
            }

            return false;
        },
        getHolidaysByDay(day) {
            const thisDate = this.$moment(day.full_date).format('YYYY-MM-DD');

            return this.holidays[thisDate];
        },
        dayClickHandler(e) {
            let currentDate = new Date()
            this.swichToDate(`${currentDate.getMonth() + 1}/${e.index}/${currentDate.getFullYear()}`)
        },
        capitalizeFirstLetter(str) {
            return str.charAt(0).toUpperCase() + str.slice(1);
        },
    },
}
</script>

<style scoped>
.head td {
    width: 100px;
}
.head th{
    width: 25px;
}

table {
    width: 100%;
    border-collapse: collapse;
    border: 2px solid white;
    color: #B2B2B2;
    left: 26.2%;
    top: 200px;
    background: white;
}

td, th {
    padding: 15px 20px;
    border: 1px solid #B2B2B2;
    text-align: left;
    white-space: nowrap;
    font-weight: bold;
    font-size: 12px;
    line-height: 30px;
    background: white;
    color: #808080;
}



.table-month thead td a{
    font-style: normal;
    font-weight: 900;
    font-size: 12px;
    line-height: 90px;
    text-align: center;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: #B3B3B3;
}

.table-month td {
    width: 14.286%;
    font-family: Roboto;
    font-style: normal;
    font-weight: bold;
    font-size: 14px;
    line-height: 30px;
    text-align: right;
    min-height: 90px;
    vertical-align: top;
    /*padding-right: 10px;*/
    color: #CCCCCC;
    border: 1px solid #F5F5F5;
}
.today {
    color: black;
    text-decoration: none;
}
a {
    text-decoration: none;
}
.daygrid-day-number a, .daygrid-day-number-without-ukr a {
    cursor: pointer;
    color: inherit;
    text-decoration: none;
    padding-left: 10px;
}

.daygrid-day-reminder {
    margin: 2px;
    padding: 5px;
    line-height: 14px;
    cursor: pointer;
    background: #FEEACC;
    border-radius: 4px;
    font-family: Roboto;
    font-style: normal;
    font-weight: bold;
    font-size: 12px;
    color: #D46D2C;
    text-align: center;
}

.daygrid-day-task {
    margin: 2px;
    padding: 5px;
    line-height: 14px;
    cursor: pointer;
    font-style: normal;
    font-weight: bold;
    font-size: 12px;
    color: #008911;
    background: #E0F7D7;
    border-radius: 4px;
    text-align: center;
}

.daygrid-day-birthday {
    margin: 2px;
    padding: 5px;
    line-height: 14px;
    cursor: pointer;
    font-style: normal;
    font-weight: bold;
    font-size: 12px;
    color: #2675B5;
    background: #D2EFFE;
    text-align: center;
    border-radius: 4px;
}

.daygrid-day-event {
    margin: 2px;
    padding: 5px;
    line-height: 14px;
    cursor: pointer;
    background: #F5E3F9;
    border-radius: 4px;
    font-weight: bold;
    font-size: 12px;
    color: #86488A;
    text-align: center;
}
.daygrid-day-number a{
    padding-right: 10px;
}

.daygrid-day-number {
    width: 25px;
    text-decoration: none;
}

.holiday {
    /*width: 25px;*/
    /*height: 25px;*/
    color: #ffff;
    background: red;
    border-radius: 3px;
    text-align: center;
    line-height: 24px;
    text-decoration: none;
}
.daygrid-day-ukr {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
    color: #222222;
    font-weight: bold;
    text-align: left;
    padding-left: 5px;
    line-height: 18px;

}
</style>

