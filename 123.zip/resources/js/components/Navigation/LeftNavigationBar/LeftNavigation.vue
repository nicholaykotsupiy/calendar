<template>
    <ul class="col-2 col-sm-1 h-auto nav-list">
        <li class="list-item d-flex flex-column align-items-center py-2">
            <a href="http://it20auth.pp.ua/home" class="d-flex flex-column align-items-center">
                <svg width="33" height="30" viewBox="0 0 33 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                <mask id="mask0" mask-type="alpha" maskUnits="userSpaceOnUse" x="5" y="5" width="23" height="17">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M14.3375 22V16H18.6625V22H24.0688V14H27.3125L16.5 5L5.6875 14H8.93125V22H14.3375Z" fill="white"/>
                </mask>
                <g mask="url(#mask0)">
                    <rect x="2.44336" y="2" width="28.1125" height="26" fill="#D8D8D8"/>
                </g>
            </svg>
             <span class="title d-none d-lg-block">
                 Главная
             </span>
            </a>
        </li>
        <li class="list-item d-flex flex-column align-items-center py-2">
            <a href="http://disk.hardsoft.space/disk" class="d-flex flex-column align-items-center">
                <svg width="33" height="30" viewBox="0 0 33 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                <mask id="mask1" mask-type="alpha" maskUnits="userSpaceOnUse" x="3" y="7" width="27" height="16">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M24.4476 13.04C23.7123 9.59 20.4361 7 16.5004 7C13.3756 7 10.6616 8.64 9.31008 11.04C6.05552 11.36 3.52539 13.91 3.52539 17C3.52539 20.31 6.43395 23 10.0129 23H24.0691C27.0534 23 29.4754 20.76 29.4754 18C29.4754 15.36 27.2588 13.22 24.4476 13.04ZM21.9067 16L16.5004 21L11.0942 16H14.3379V12H18.6629V16H21.9067Z" fill="white"/>
                </mask>
                <g mask="url(#mask1)">
                    <rect x="2.44336" y="2" width="28.1125" height="26" fill="#D8D8D8"/>
                </g>
            </svg>
            <span class="title d-none d-lg-block">
                Диск
            </span>
            </a>
        </li>
        <li class="active list-item d-flex flex-column align-items-center py-2">
            <a href="#" class="d-flex flex-column align-items-center">
                <svg width="33" height="30" viewBox="0 0 33 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                <mask id="mask3" mask-type="alpha" maskUnits="userSpaceOnUse" x="6" y="5" width="21" height="20">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M23.9875 7H22.9062V5H20.7437V7H12.0937V5H9.93125V7H8.85C7.64981 7 6.69831 7.9 6.69831 9L6.6875 23C6.6875 24.1 7.64981 25 8.85 25H23.9875C25.1769 25 26.15 24.1 26.15 23V9C26.15 7.9 25.1769 7 23.9875 7ZM23.9875 23H8.85001V12H23.9875V23ZM11.0125 14H16.4188V19H11.0125V14Z" fill="white"/>
                </mask>
                <g mask="url(#mask3)">
                    <rect x="2.3623" y="2" width="28.1125" height="26" fill="#D8D8D8"/>
                </g>
            </svg>
            <span class="title d-none d-lg-block">
                Календарь
            </span>
            </a>
        </li>
        <li class="list-item d-flex flex-column align-items-center py-2">
            <a href="http://www.ignatenko-project.store/checkPhoto" class="d-flex flex-column align-items-center">
                <svg width="33" height="30" viewBox="0 0 33 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                <mask id="mask4" mask-type="alpha" maskUnits="userSpaceOnUse" x="5" y="6" width="23" height="18">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M11.2776 8L13.2563 6H19.7438L21.7224 8H25.15C26.3394 8 27.3125 8.9 27.3125 10V22C27.3125 23.1 26.3394 24 25.15 24H7.85C6.66063 24 5.6875 23.1 5.6875 22V10C5.6875 8.9 6.66063 8 7.85 8H11.2776ZM11.0938 16C11.0938 18.76 13.5158 21 16.5 21C19.4843 21 21.9063 18.76 21.9063 16C21.9063 13.24 19.4843 11 16.5 11C13.5158 11 11.0938 13.24 11.0938 16Z" fill="white"/>
                </mask>
                <g mask="url(#mask4)">
                    <rect x="2.44336" y="2" width="28.1125" height="26" fill="#D8D8D8"/>
                </g>
            </svg>
            <span class="title d-none d-lg-block">
                Фотографии
            </span>
            </a>
        </li>
        <li class="list-item d-flex flex-column align-items-center py-2">
            <a href="http://calendar.hardsoft.space/" class="d-flex flex-column align-items-center">
                <svg width="33" height="30" viewBox="0 0 33 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                <mask id="mask5" mask-type="alpha" maskUnits="userSpaceOnUse" x="4" y="8" width="25" height="14">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M20.9873 14C22.7822 14 24.2202 12.66 24.2202 11C24.2202 9.34 22.7822 8 20.9873 8C19.1924 8 17.7435 9.34 17.7435 11C17.7435 12.66 19.1924 14 20.9873 14ZM12.3373 14C14.1322 14 15.5702 12.66 15.5702 11C15.5702 9.34 14.1322 8 12.3373 8C10.5424 8 9.09356 9.34 9.09356 11C9.09356 12.66 10.5424 14 12.3373 14ZM12.3373 16C9.81799 16 4.76855 17.17 4.76855 19.5V22H19.9061V19.5C19.9061 17.17 14.8566 16 12.3373 16ZM20.9873 16C20.6737 16 20.3169 16.02 19.9385 16.05C21.1927 16.89 22.0685 18.02 22.0685 19.5V22H28.556V19.5C28.556 17.17 23.5066 16 20.9873 16Z" fill="white"/>
                </mask>
                <g mask="url(#mask5)">
                    <rect x="2.60547" y="2" width="28.1125" height="26" fill="#D8D8D8"/>
                </g>
            </svg>
            <span class="title d-none d-lg-block">
                Контакты
            </span>
            </a>
        </li>
    </ul>
</template>

<script>
export default {
    name: "LeftNavigation"
}
</script>

<style scoped>
    .nav-list {
        margin: 0;
        padding: 0;
        height: 100%;
        background: #FFFFFF;
        box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.05);
    }
    .list-item {
        list-style: none;
        cursor: pointer;
    }
    .title {
        font-family: Roboto;
        font-weight: 600;
        font-size: 13px;
        line-height: 30px;
        color: #999999;
    }
    .active {
        border-left: 2px solid #1875F0;
    }
    .active svg path, .active svg rect{
        fill: #1875F0;
    }
</style>
